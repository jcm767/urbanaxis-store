export default function Refunds(){return <main><h1>Refunds</h1><p>30-day returns on unworn items.</p></main>};

'use client';

import { useState } from 'react';

export default function Home() {
  const [loading, setLoading] = useState(false);
  const onBuy = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/checkout', { method: 'POST' });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
      else alert('No checkout URL returned');
    } catch (e:any) {
      alert(e?.message ?? 'Checkout failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main>
      <h1>Urban Axis</h1>
      <p>Click below to checkout with Stripe:</p>
      <button onClick={onBuy} disabled={loading} style={{ padding: '10px 16px', borderRadius: 8 }}>
        {loading ? 'Loading…' : 'Buy'}
      </button>
    </main>
  );
}

// Force Node.js runtime for Stripe SDK
export const runtime = 'nodejs';

import { NextResponse } from 'next/server';
import { getStripe } from '@/lib/stripe';

export async function POST() {
  const stripe = getStripe();

  const site = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  const price = process.env.STRIPE_PRICE_ID;
  if (!price) {
    return NextResponse.json({ error: 'Missing STRIPE_PRICE_ID' }, { status: 500 });
  }

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: [{ price, quantity: 1 }],
    success_url: `${site}/success`,
    cancel_url: `${site}/`
  });

  return NextResponse.json({ url: session.url });
}

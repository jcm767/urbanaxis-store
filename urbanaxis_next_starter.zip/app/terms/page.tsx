export default function Terms(){return <main><h1>Terms</h1><p>Standard terms go here.</p></main>};

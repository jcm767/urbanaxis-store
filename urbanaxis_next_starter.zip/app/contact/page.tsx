export default function Contact(){return <main><h1>Contact</h1><p>Email: support@theurbanaxis.com</p></main>};

export default function SuccessPage() {
  return (
    <main>
      <h1>Payment Successful</h1>
      <p>Thanks for your order! You will receive an email confirmation shortly.</p>
    </main>
  );
}

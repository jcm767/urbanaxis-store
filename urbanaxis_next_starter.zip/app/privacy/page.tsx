export default function Privacy(){return <main><h1>Privacy</h1><p>Standard privacy policy.</p></main>};
